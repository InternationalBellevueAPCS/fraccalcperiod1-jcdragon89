import java.util.*;
public class FracCalc {

    /**
     * Prompts user for input, passes that input to produceAnswer, then outputs the result.
     * @param args - unused
     */
    public static void main(String[] args)     {
        // TODO: Read the input from the user and call produceAnswer with an equation
        // Checkpoint 1: Create a Scanner, read one line of input, pass that input to produceAnswer, print the result.
        // Checkpoint 2: Accept user input multiple times.
    	Scanner console = new Scanner(System.in);
    	
    	System.out.println("Welcome to the Fraction Calculator!");
    	System.out.println("-----------------------------------------------------");
    	System.out.println("Type a _ after a whole number and a space between fraction and operation");
    	
    	System.out.print("Type an fraction equation or quit to finish: ");
    	String equation = console.nextLine();
    	
    	
    	
    	while (equation != "quit") {
    		System.out.println(produceAnswer(equation));
    		System.out.print("Type an fraction equation or quit to finish: ");
    		equation = console.nextLine();
    	}

    }
    
    /**
     * produceAnswer - This function takes a String 'input' and produces the result.
     * @param input - A fraction string that needs to be evaluated.  For your program, this will be the user input.
     *      Example: input ==> "1/2 + 3/4"
     * @return the result of the fraction after it has been calculated.
     *      Example: return ==> "1_1/4"
     */
    public static String produceAnswer(String input)    { 
        // TODO: Implement this function to produce the solution to the input
        // Checkpoint 1: Return the second operand.  Example "4/5 * 1_2/4" returns "1_2/4".
        // Checkpoint 2: Return the second operand as a string representing each part.
        //               Example "4/5 * 1_2/4" returns "whole:1 numerator:2 denominator:4".
        // Checkpoint 3: Evaluate the formula and return the result as a fraction.
        //               Example "4/5 * 1_2/4" returns "6/5".
        //               Note: Answer does not need to be reduced, but it must be correct.
        // Final project: All answers must be reduced.
        //               Example "4/5 * 1_2/4" returns "1_1/5".

    	// Finding the first fraction
    	String num1 = "";
    	String op = "";
    	String num2 = "";
    	
    	String temp = "";
    	
    	
    	// Finding the fractions and operators
    	for (int i = 0; i < input.length(); i++) { 
    		if (input.charAt(i) == ' ') {
    			if (num1.equals("")) {
    				num1 = temp;
    				temp = "";
    			} else {
    				op = temp;
    				temp = "";
    			}
    		} else if (i == input.length() - 1) {
    			temp += input.charAt(i);
    			num2 = temp;
    		} else {
    			temp += input.charAt(i);
    		}
    	}
    	
    	// Finding the parts of the fractions for fraction 2
    	int num2W = Integer.parseInt(wholeNum(num2));
    	int num2N = Integer.parseInt(numerNum(num2));
    	int num2D = Integer.parseInt(denomNum(num2));
    	
    	
    	// Finding the parts of the fraction for fraction 1
    	int num1W = Integer.parseInt(wholeNum(num1));
    	int num1N = Integer.parseInt(numerNum(num1));
    	int num1D = Integer.parseInt(denomNum(num1));
    	
    	// Variables for GCD
  /*  	int a = 0;
    	int b = 0;	*/
    	

    // First Number is a Mixed Number 
    	if (num1.contains("_")) {
    		
    		if (num2.contains("_")) {	//  Second Number is a Mixed Number

        		num1N = (num1W * num1D) + num1N;
    			num2N = (num2W * num2D) + num2N;
    			if (op.equals("+")) {	// Addition
    				if (num1D != num2D) {
    					num1N *= num2D;
	    				num2N *= num1D;
	    				num1D *= num2D;
    				} 
    				
    				num1N += num2N;
    				
    				int gcd = greatestCommonDivisor(num1N, num1D); 
    				return (num1N/gcd) + "/" + (num1D/gcd);    				
    			} else if (op.equals("-")) {	// Subtraction
    				if (num1D != num2D) {
    					num1N *= num2D;
	    				num2N *= num1D;
	    				num1D *= num2D;
    				} 
    				
    				num1N -= num2N;
    				
    				int gcd = greatestCommonDivisor(num1N, num1D); 
    				return (num1N/gcd) + "/" + (num1D/gcd);
    			} else if (op.equals("*")) { 	// Multiplication
    				num1N *= num2N;
    				num1D *= num2D;
    				
    				int gcd = greatestCommonDivisor(num1N, num1D);
    				return (num1N/gcd) + "/" + (num1D/gcd);
    			} else {	// Division
    				int x = num2N;
    				num2N = num2D;
    				num2D = x;
    				
    				num1N *= num2N;
    				num1D *= num2D;
    				
    				int gcd = greatestCommonDivisor(num1N, num1D);
    				return (num1N/gcd) + "/" + (num1D/gcd);
    			}
    			
    		} else if (num2.contains("/")) {	//  Second Number is a Fraction
    			num1N = (num1W * num1D) + num1N;
    			if (op.equals("+")) {	// Addition
    				if (num1D != num2D) {
    					num1N *= num2D;
	    				num2N *= num1D;
	    				num1D *= num2D;
    				} 
    				
    				num1N += num2N;
    				
    				int gcd = greatestCommonDivisor(num1N, num1D); 
    				return (num1N/gcd) + "/" + (num1D/gcd);    				
    			} else if (op.equals("-")) {	// Subtraction
    				if (num1D != num2D) {
    					num1N *= num2D;
	    				num2N *= num1D;
	    				num1D *= num2D;
    				} 
    				
    				num1N -= num2N;
    				
    				int gcd = greatestCommonDivisor(num1N, num1D); 
    				return (num1N/gcd) + "/" + (num1D/gcd);
    			} else if (op.equals("*")) { 	// Multiplication
    				num1N *= num2N;
    				num1D *= num2D;
    				
    				int gcd = greatestCommonDivisor(num1N, num1D);
    				return (num1N/gcd) + "/" + (num1D/gcd);
    			} else {	// Division
    				int x = num2N;
    				num2N = num2D;
    				num2D = x;
    				
    				num1N *= num2N;
    				num1D *= num2D;
    				
    				int gcd = greatestCommonDivisor(num1N, num1D);
    				return (num1N/gcd) + "/" + (num1D/gcd);
    			}
		    
			    	
    		} else {	//  Second Number is Whole
    			
    			if (op.equals("+")) {	// Addition
    				num1W += num2W;
    				
    				int gcd = greatestCommonDivisor(num1N, num1D); 
    				return num1W + "_" + (num1N/gcd) + "/" + (num1D/gcd);    				
    			} else if (op.equals("-")) {	// Subtraction
    				num1W -= num2W;
    				
    				int gcd = greatestCommonDivisor(num1N, num1D); 
    				return num1W + "_" + (num1N/gcd) + "/" + (num1D/gcd);
    			} else if (op.equals("*")) { 	// Multiplication
    				num1N = (num1W * num1D) +num1N;
    				num1N *= num2W;
    				
    				
    				int gcd = greatestCommonDivisor(num1N, num1D);
    				return (num1N/gcd) + "/" + (num1D/gcd);
    			} else {	// Division
    				num2N = num2W;
    				int x = num2N;
    				num2N = num2D;
    				num2D = x;
    				
    				num1D *= num2D;
    				
    				int gcd = greatestCommonDivisor(num1N, num1D);
    				return (num1N/gcd) + "/" + (num1D/gcd);
    			}
		    
    		
    		}	
    	} else if (num1.contains("/")) {		// First Number is a Fraction
    		
    		if (num2.contains("_")) {	//  Second Number is a Mixed Number

    			num2N = (num2W * num2D) + num2N;
    			if (op.equals("+")) {	// Addition
    				if (num1D != num2D) {
    					num1N *= num2D;
	    				num2N *= num1D;
	    				num1D *= num2D;
    				} 
    				
    				num1N += num2N;
    				
    				int gcd = greatestCommonDivisor(num1N, num1D); 
    				return (num1N/gcd) + "/" + (num1D/gcd);    				
    			} else if (op.equals("-")) {	// Subtraction
    				if (num1D != num2D) {
    					num1N *= num2D;
	    				num2N *= num1D;
	    				num1D *= num2D;
    				} 
    				
    				num1N -= num2N;
    				
    				int gcd = greatestCommonDivisor(num1N, num1D); 
    				return (num1N/gcd) + "/" + (num1D/gcd);
    			} else if (op.equals("*")) { 	// Multiplication
    				num1N *= num2N;
    				num1D *= num2D;
    				
    				int gcd = greatestCommonDivisor(num1N, num1D);
    				return (num1N/gcd) + "/" + (num1D/gcd);
    			} else {	// Division
    				int x = num2N;
    				num2N = num2D;
    				num2D = x;
    				
    				num1N *= num2N;
    				num1D *= num2D;
    				
    				int gcd = greatestCommonDivisor(num1N, num1D);
    				return (num1N/gcd) + "/" + (num1D/gcd);
    			}
    			
    		} else if (num2.contains("/")) {	//  Second Number is a Fraction
    			num1N = (num1W * num1D) + num1N;
    			if (op.equals("+")) {	// Addition
    				if (num1D != num2D) {
    					num1N *= num2D;
	    				num2N *= num1D;
	    				num1D *= num2D;
    				} 
    				
    				num1N += num2N;
    				
    				int gcd = greatestCommonDivisor(num1N, num1D); 
    				return (num1N/gcd) + "/" + (num1D/gcd);    				
    			} else if (op.equals("-")) {	// Subtraction
    				if (num1D != num2D) {
    					num1N *= num2D;
	    				num2N *= num1D;
	    				num1D *= num2D;
    				} 
    				
    				num1N -= num2N;
    				
    				int gcd = greatestCommonDivisor(num1N, num1D); 
    				return (num1N/gcd) + "/" + (num1D/gcd);
    			} else if (op.equals("*")) { 	// Multiplication
    				num1N *= num2N;
    				num1D *= num2D;
    				
    				int gcd = greatestCommonDivisor(num1N, num1D);
    				return (num1N/gcd) + "/" + (num1D/gcd);
    			} else {	// Division
    				int x = num2N;
    				num2N = num2D;
    				num2D = x;
    				
    				num1N *= num2N;
    				num1D *= num2D;
    				
    				int gcd = greatestCommonDivisor(num1N, num1D);
    				return (num1N/gcd) + "/" + (num1D/gcd);
    			}
		    
			    	
    		} else {	//  Second Number is Whole
    			
    			if (op.equals("+")) {	// Addition
    				num1W += num2W;
    				
    				int gcd = greatestCommonDivisor(num1N, num1D); 
    				return num1W + "_" + (num1N/gcd) + "/" + (num1D/gcd);    				
    			} else if (op.equals("-")) {	// Subtraction
    				num1W -= num2W;
    				
    				int gcd = greatestCommonDivisor(num1N, num1D); 
    				return num1W + "_" + (num1N/gcd) + "/" + (num1D/gcd);
    			} else if (op.equals("*")) { 	// Multiplication
    				num1N = (num1W * num1D) +num1N;
    				num1N *= num2W;
    				
    				
    				int gcd = greatestCommonDivisor(num1N, num1D);
    				return (num1N/gcd) + "/" + (num1D/gcd);
    			} else {	// Division
    				num2N = num2W;
    				int x = num2N;
    				num2N = num2D;
    				num2D = x;
    				
    				num1D *= num2D;
    				
    				int gcd = greatestCommonDivisor(num1N, num1D);
    				return (num1N/gcd) + "/" + (num1D/gcd);
    			}
		    
    		
    		}	
    	}
    	 
    	 
    	 
    // First Number is a Whole 
    		// mixed number
	    	// Fraction
	    	// whole

    	
    return "whole:" + num2W + " numerator:" + num2N + " denominator:" + num2D;

    	
        
    }
    // TODO: Fill in the space below with helper methods
    // Finding the Whole Number
    public static String wholeNum(String str) {
    	
    	if (str.contains("_")) {
    		return str.substring(0, str.indexOf('_'));
    	}else if (str.contains("/")) {
    		return "0";
    	} else {
    		return str;
    	}
    	
    }
    // Finding the Numerator
    public static String numerNum(String str) {
    	
    	if (str.contains("_")) {
    		return str.substring(str.indexOf('_') + 1, str.indexOf('/'));
    	}else if (str.contains("/")) {
    		return str.substring(0, str.indexOf('/'));
    	} else {
    		return "0";
    	}
    	
    }
    // Finding the Denominator 
    public static String denomNum(String str) {
 
    	if (str.contains("/")) {
    		return str.substring(str.indexOf('/') + 1);
    	} else {
    		return "1";
    	}
    	
    }
    
    
    
    
    /**
     * greatestCommonDivisor - Find the largest integer that evenly divides two integers.
     *      Use this helper method in the Final Checkpoint to reduce fractions.
     *      Note: There is a different (recursive) implementation in BJP Chapter 12.
     * @param a - First integer.
     * @param b - Second integer.
     * @return The GCD.
     */
    public static int greatestCommonDivisor(int a, int b)    {
        a = Math.abs(a);
        b = Math.abs(b);
        int max = Math.max(a, b);
        int min = Math.min(a, b);
        while (min != 0) {
            int tmp = min;
            min = max % min;
            max = tmp;
        }
        return max;
    }
    
    /**
     * leastCommonMultiple - Find the smallest integer that can be evenly divided by two integers.
     *      Use this helper method in Checkpoint 3 to evaluate expressions.
     * @param a - First integer.
     * @param b - Second integer.
     * @return The LCM.
     */
    public static int leastCommonMultiple(int a, int b)    {
        int gcd = greatestCommonDivisor(a, b);
        return (a*b)/gcd;
    }
}
